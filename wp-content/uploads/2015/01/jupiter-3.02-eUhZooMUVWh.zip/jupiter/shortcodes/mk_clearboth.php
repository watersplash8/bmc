<?php

echo '<div class="clearboth"></div>';